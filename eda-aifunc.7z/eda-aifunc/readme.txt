1.递增斜波increase、递减斜波decrease、方波square、三角波delta、正弦波sin、阶梯波ladder;
2.mux61为六选一数据选择器，选择输出0哪一种波形；
3.aifunc为主项目，例化上述七种元件。